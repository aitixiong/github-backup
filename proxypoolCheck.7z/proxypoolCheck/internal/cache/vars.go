package cache

var (
	AllProxiesCount    = 0
	SSRProxiesCount    = 0
	SSProxiesCount     = 0
	VmessProxiesCount  = 0
	TrojanProxiesCount = 0

	UsableProxiesCount = 0

	LastCrawlTime = "Loading……"
)