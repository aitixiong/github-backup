go-bindata -o api/html.go -pkg api  assets/html/ assets/css
